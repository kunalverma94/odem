
const setting=
{
    nav:false,
}
function Toggle()
{
    document.getElementById("sidenav").classList.toggle("nav_open");
    document.getElementById("main").classList.toggle("main_open");
    document.getElementById("toggler").classList.toggle("togggler_left");
        
}

window.onload=function()
{
}